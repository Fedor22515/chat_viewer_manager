# Chatlog Viewer (GitHub Pages)

这是一个可直接部署到 GitHub Pages 的最小仓库结构：

- `index.html`：你的页面（已由 ChatGPT_Viwer3.2.html 改名）
- `.nojekyll`：避免 Jekyll 干扰静态文件

## 发布到 GitHub Pages
1. 在 GitHub 新建仓库并推送本目录所有文件到仓库根目录。
2. 仓库 Settings → Pages：选择 **Deploy from a branch**，**Branch = main**，**/ (root)**。
3. 稍等片刻即可在 `https://<你的用户名>.github.io/<仓库名>/` 访问。
